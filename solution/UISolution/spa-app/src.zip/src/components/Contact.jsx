function Contact() {
    return (
      <div>
        <h1>Transflower Leraning Pvt. Ltd.</h1>
        <p>Email: ravi.tambade@tranflower.in</p>
        <p>Contact Number:9881735801</p>
        <p>Location: Pune</p>
      </div>
    );
  }

  export default Contact;
