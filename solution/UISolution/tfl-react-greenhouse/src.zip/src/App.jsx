import List from "./components/List";
import Login from "./components/Login";
function App() {
  return (
    <>
      <div>

        <h2>Todays fresh flowers from Tambade mala</h2>
        <hr/>
      
         <List/>
        </div>
    </>
  )
}
export default App;
//  <Login/>